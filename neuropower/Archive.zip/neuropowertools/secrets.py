OPBEAT={
    'ORGANIZATION_ID': 'ef1586e347da4af78b3303a65e2025a6',
    'APP_ID': '9abbe5d7a5',
    'SECRET_TOKEN': 'e39574b61ae2cdc7d5a40eb3f28dd028e4ed2a62',
}

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY =  "@sc_pxiu+hjyf+kdex&*0n@d#@^xnvgma10=)*14innt#boy72"

MAILGUN_KEY = 'api:key-c26b8eba519d6da25cd9a89a59258251'
