OPBEAT={
    'ORGANIZATION_ID': 'bogus',
    'APP_ID': 'bogus',
    'SECRET_TOKEN': 'bogus',
}

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY =  "bogus"
