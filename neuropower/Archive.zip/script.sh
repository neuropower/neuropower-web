docker-machine create --driver virtualbox neuropower
docker-machine start default
eval $(docker-machine env default)
docker-machine ip default
docker pull neuropower/neuropower

docker build -t neuropower/neuropower .
docker push neuropower/neuropower
docker-compose up
docker ps
docker exec -it d8f57dade61f bash
source activate crnenv
python manage.py makemigrations
python manage.py migrate
python manage.py dbshell


docker run -v /Users/Joke/Downloads:/local -it neuropower/neuropower bash
docker run -it joke/neuropower bash
docker run -v /Users/Joke/Downloads/:/local -it neuropower/neuropower python /local/GeneticAlgorithm_h2gu66qcxjgr0ibuzrhj0m3rnmh3boq9.py


docker-compose restart
docker-compose stop

docker rmi $(docker images -a)
docker rm $(docker ps -a)

docker build -t joke/aws-eb-docker-django-skeleton .
docker push joke/aws-eb-docker-django-skeleton
eb init

eb create np-2


eb create np-1 -i t2.medium --timeout 50 --region us-west-1


lsblk
ln -s /dev/xvda1 /var/lib/docker

ssh -i ~/Documents/Onderzoek/ProjectsOngoing/Neuropower/AWSLinuxinstance.pem ec2-user@ec2-52-53-255-129.us-west-1.compute.amazonaws.com

scp -i ~/Documents/Onderzoek/ProjectsOngoing/Neuropower/AWSLinuxinstance.pem ./secrets.py ec2-user@ec2-54-153-7-42.us-west-1.compute.amazonaws.com:/home/ec2-user/neuropower-web/neuropower/neuropowertools/


docker pull micahhausler/container-transform:latest
docker run --rm -v $(pwd):/data/ micahhausler/container-transform docker-compose.yml > Dockerrun.aws.json
eb init
eb create neuropower-2




brew install docker docker-machine docker-compose
docker-machine ls
docker-machine help
docker-machine create --driver virtualbox
docker-machine env neuro
eval "$(docker-machine env neuro)"
docker ps
cd ..
git clone https://github.com/NeuroVault/NeuroVault.git
cd neuropower/
cp ../NeuroVault/Dockerfile .
atom Dockerfile
export ATOM_PATH=/Applications/Atom\ 2.app/
atom Dockerfile
nano Dockerfile
docker build -t filo/neuropower .
cat neuropower/requirements.txt
nano Dockerfile

docker build -t filo/neuropower .
mv Dockerfile neuropower/
docker run -it filo/neuropower python
docker ps

docker ps -a

nano Dockerfile
